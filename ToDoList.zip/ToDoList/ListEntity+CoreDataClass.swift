//
//  ListEntity+CoreDataClass.swift
//  ToDoList
//
//  Created by Nguyễn Thịnh Tiến on 2/24/17.
//  Copyright © 2017 TienNguyen. All rights reserved.
//

import Foundation
import CoreData

@objc(ListEntity)
public class ListEntity: NSManagedObject {
    
    class func find(byId id: String) -> ListEntity?{
        
        
        return nil
    }
    
//    class func new(w)
}
