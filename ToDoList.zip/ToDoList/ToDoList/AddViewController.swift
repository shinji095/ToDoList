//
//  AddViewController.swift
//  ToDoList
//
//  Created by Nguyễn Thịnh Tiến on 2/24/17.
//  Copyright © 2017 TienNguyen. All rights reserved.
//

import UIKit
import CoreData
import Alamofire

class AddViewController: UIViewController {

    @IBOutlet weak var titleTextFeild: UITextField!
    
    @IBOutlet weak var contentTextView: UITextView!
    
    var userId: String?
    
    var postUrl = "http://124.158.7.238:3010/api/notes"
    
    @IBAction func addData(_ sender: Any) {
        
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "tableVC") as? ViewController
            if VC != nil {
                
                let title = titleTextFeild.text
                let content = contentTextView.text
                
                let paramsNote = [
                    "title":title!,
                    "content":content!,
                    "user_id": userId!,
                    "createdAt": VC!.convertDatetoString(date: NSDate())
                ]
                
                Alamofire.request(postUrl, method: .post, parameters: paramsNote).responseJSON {
                    response in
                    VC?.delData()
                    VC?.fetchData()
                    VC?.getData()
                    VC?.userId = self.userId
                }
        }
        
        self.navigationController?.pushViewController(VC!, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        contentTextView.layer.borderWidth = 0.8
        contentTextView.layer.borderColor = UIColor(colorLiteralRed: 0, green: 0, blue: 0, alpha: 0.5).cgColor
        contentTextView.layer.cornerRadius = 8
        
        self.hideKeyboard()
        
        // hidden keyboard
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
