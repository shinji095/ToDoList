//
//  AddViewController.swift
//  ToDoList
//
//  Created by Nguyễn Thịnh Tiến on 2/24/17.
//  Copyright © 2017 TienNguyen. All rights reserved.
//

import UIKit
import CoreData
import Alamofire

class AddViewController: UIViewController {

    @IBOutlet weak var titleTextFeild: UITextField!
    
    @IBOutlet weak var contentTextField: UITextField!
    
    var userId: String?
    
    var postUrl = "http://124.158.7.238:3010/api/notes"
    
    @IBAction func addData(_ sender: Any) {
        
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "tableVC") as? ViewController
            if VC != nil {
                
                let title = titleTextFeild.text
                let content = contentTextField.text
                let paramsNote = [
                    "title":title!,
                    "content":content!,
                    "user_id": "58b7c43f09d52e5b0c92d4bd",
                    "createdAt": VC!.convertDatetoString(date: NSDate())
                ]
                
                Alamofire.request(postUrl, method: .post, parameters: paramsNote).responseJSON {
                    response in
                }
                
                let listEntity: NSEntityDescription? = NSEntityDescription.entity(forEntityName: "ListEntity", in: (VC?.getContext())!)
                if listEntity != nil {
                    let note1 : ListEntity = ListEntity(entity: listEntity!, insertInto: VC!.getContext())
                    note1.content = contentTextField.text
                    note1.title = titleTextFeild.text
                    note1.createdAt = NSDate()
                    note1.userId = userId
                    VC?.lists.append(note1)
                    VC?.appDelegate.coreDataStack.saveContext()
                }
        }
        VC?.delData()
        VC?.fetchData()
        Alamofire.request(postUrl, method: .get).responseJSON {
            response in
            
            do{
                VC?.listData = try JSONSerialization.jsonObject(with: response.data!, options: .mutableContainers) as! [NSDictionary]
            }
            catch {
                print(error)
            }
            for i in 0..<VC!.listData.count {
                let item = VC?.listData[i]
                let title = item?["title"]
                let content = item?["content"]
                let createdAt = item?["createdAt"]
                let id = item?["id"] as! String
                let userId = item?["user_id"] as! String
                
                if userId == self.userId {
                    let listEntity: NSEntityDescription? = NSEntityDescription.entity(forEntityName: "ListEntity", in: (VC?.appDelegate.coreDataStack.managedObjectContext)!)
                    
                    if listEntity != nil {
                        let note1: ListEntity = ListEntity(entity: listEntity!, insertInto: VC!.appDelegate.coreDataStack.managedObjectContext)
                        note1.title = title as! String?
                        note1.content = content as! String?
                        note1.createdAt = VC?.convertStringtoDate(str: (createdAt as! String)) as NSDate?
                        note1.id = id as String?
                        note1.userId = userId as String?
                        VC?.lists.append(note1)
                        VC?.tableView.reloadData()
                        VC?.appDelegate.coreDataStack.saveContext()
                    }
                }
            }
        }
        self.navigationController?.pushViewController(VC!, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
