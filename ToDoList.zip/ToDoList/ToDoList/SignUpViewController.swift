//
//  SignUpViewController.swift
//  ToDoList
//
//  Created by Nguyễn Thịnh Tiến on 2/28/17.
//  Copyright © 2017 TienNguyen. All rights reserved.
//

import UIKit
import Alamofire

class SignUpViewController: UIViewController {
    @IBOutlet weak var userTxf: UITextField!

    @IBOutlet weak var passTxf: UITextField!
    
    @IBOutlet weak var cfPassTxf: UITextField!
    
    let urlSignUp: String = "http://124.158.7.238:3010/api/users"
    
    let urlString = "http://124.158.7.238:3010/api/users/login"
    
    @IBAction func signUpAccount(_ sender: Any) {
        
        let userString = userTxf.text
        let passString = passTxf.text
        let cfPassString = cfPassTxf.text
        if userString != nil || passString != nil {
            if (passString == cfPassString) {
                let paramUser: [String : AnyObject] = [
                    "email" : userString! as AnyObject,
                    "password" : passString! as AnyObject
                ]
                
                Alamofire.request(urlSignUp, method: .post, parameters: paramUser).responseJSON {
                    response in
                    if response.response?.statusCode == 200 {
                        let VC = self.storyboard?.instantiateViewController(withIdentifier: "tableVC") as? ViewController
                        Alamofire.request(self.urlString, method: .post, parameters: paramUser).responseJSON {
                            response in
                            if let data: AnyObject = response.result.value as AnyObject? {
                                let id = data["userId"] as? String
                                VC?.userId = id
                                VC?.getData()
                            }
                        }
                        self.navigationController?.pushViewController(VC!, animated: true)
                        
                    }
                    else {
                        let alert = UIAlertController(title: "Alert", message: "Error", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "Back", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
            else {
                let alert = UIAlertController(title: "Alert", message: "Confirm password not match, Please check again", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Back", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        else {
            let alert = UIAlertController(title: "Alert", message: "Username or password is empty. Please check again", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Back", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        UITextField.animate(withDuration: 0.5, animations: {
            self.userTxf.frame.origin.x += 70
        },completion: nil)
        UITextField.animate(withDuration: 1, animations: {
            self.passTxf.frame.origin.x += 100
        },completion: nil)
        UITextField.animate(withDuration: 1.5, animations: {
            self.cfPassTxf.frame.origin.x += 130
        },completion: nil)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
