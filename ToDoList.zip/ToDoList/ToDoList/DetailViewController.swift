//
//  DetailViewController.swift
//  ToDoList
//
//  Created by Nguyễn Thịnh Tiến on 2/23/17.
//  Copyright © 2017 TienNguyen. All rights reserved.
//

import UIKit
import Alamofire
import CoreData

class DetailViewController: UIViewController {
    
    var contentText: String?
    var titleText: String?
    var dateCreated: String?
    var userId: String?
    var noteId: String?
    
    @IBOutlet weak var containView: UIView!
    
    @IBOutlet weak var contentTextView: UITextView!
    
    @IBOutlet weak var createdAtText: UILabel!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var editBtn: UIButton!
    
    var putUrl = "http://124.158.7.238:3010/api/notes"
    
    @IBAction func editData(_ sender: Any) {
        
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "tableVC") as? ViewController
        
        let putString = [
            "title": titleText!,
            "content": contentTextView.text!,
            "id": noteId!,
            "user_id": userId!,
            "createdAt":VC!.convertDatetoString(date: NSDate())
        ]
        
        Alamofire.request(putUrl, method: .put, parameters: putString).responseJSON {
            response in
        }
        
        Alamofire.request(putUrl, method: .get).responseJSON {
            response in
            VC?.delData()
            VC?.getData()
            VC?.fetchData()
            VC?.userId = self.userId
        }
        
        self.navigationController?.pushViewController(VC!, animated: true)
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.containView.backgroundColor = UIColor(white: 1, alpha: 0.5)
        self.contentTextView.layer.borderWidth = 0.5
        self.contentTextView.layer.cornerRadius = 5
        self.contentTextView.layer.borderColor = UIColor(colorLiteralRed: 0, green: 0, blue: 0, alpha: 0.8).cgColor
        self.contentTextView.backgroundColor = UIColor(white: 1, alpha: 0.5)
        if contentText != nil && dateCreated != nil && titleText != nil {
            self.titleLabel.text = "Title: \(titleText!)"
            self.contentTextView.text = contentText
            self.createdAtText.text = "Created At: \(dateCreated!)"
        }
        else {
            self.createdAtText.text = "None"
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    

}
