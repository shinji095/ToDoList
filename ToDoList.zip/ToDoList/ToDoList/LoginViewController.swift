//
//  LoginViewController.swift
//  ToDoList
//
//  Created by Nguyễn Thịnh Tiến on 2/28/17.
//  Copyright © 2017 TienNguyen. All rights reserved.
//

import UIKit
import Alamofire
import CoreData

class LoginViewController: UIViewController {

    @IBOutlet weak var userNameTxf: UITextField!
    
    @IBOutlet weak var passWordTxf: UITextField!
    
    @IBOutlet weak var contain: UIView!
    
    @IBOutlet weak var containAll: UIView!
    
    @IBOutlet weak var loginActivity: UIActivityIndicatorView!
    
    let urlString = "http://124.158.7.238:3010/api/users/login"
    
    var getUrl = "http://124.158.7.238:3010/api/notes"
    
    var idUser = ""
    
     @IBAction func loginBtn(_ sender: Any) {
        self.loginActivity.startAnimating()
        let textUser = userNameTxf.text
        let textPassword = passWordTxf.text
        
        if (textUser != nil || textPassword != nil) {
            let postString = [
                "email":textUser!,
                "password":textPassword!
            ]
            
            // Check id password
            Alamofire.request(urlString, method: .post, parameters: postString).responseJSON {
                response in
                if response.response?.statusCode == 200 {
                    if let data: AnyObject = response.result.value as AnyObject? {
                        let id = data["userId"] as? String
                        self.idUser = id!
                        self.loginActivity.stopAnimating()
                        self.pushDetail()
                    }
                }
                else{
                    let alert = UIAlertController(title: "Alert", message: "Email or password not correct", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Back", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
        else {
            let alert = UIAlertController(title: "Alert", message: "Username or password is empty, please try again", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Back", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
        // Push Data and show viewcontroller
    func pushDetail() {
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "tableVC") as? ViewController
        if VC != nil{
            VC?.userId = idUser
            VC?.getData()
        }
        self.navigationController?.pushViewController(VC!, animated: true)
    }
    
    // MARK: - Networking
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.hidesBackButton = true
        contain.backgroundColor = UIColor(white: 1, alpha: 0.5)
        containAll.backgroundColor = UIColor(white: 1, alpha: 0)
        
        //Animation
        UIView.animate(withDuration: 1, animations: {
            self.containAll.frame.origin.y += 80
        },completion: nil)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
