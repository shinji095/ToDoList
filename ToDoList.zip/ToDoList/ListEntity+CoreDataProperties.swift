//
//  ListEntity+CoreDataProperties.swift
//  ToDoList
//
//  Created by Nguyễn Thịnh Tiến on 2/24/17.
//  Copyright © 2017 TienNguyen. All rights reserved.
//

import Foundation
import CoreData


extension ListEntity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ListEntity> {
        return NSFetchRequest<ListEntity>(entityName: "ListEntity");
    }

    @NSManaged public var createdAt: String?
    @NSManaged public var title: String?
    @NSManaged public var content: String?
    @NSManaged public var id: String?
    @NSManaged public var userId: String?
    
    convenience init(title: String?, content: String?, createdAt: String?, id: String?, userId: String?) {
        self.init()
        self.title = title
        self.content = content
        self.createdAt = createdAt
        self.id = id
        self.userId = userId
    }

}
